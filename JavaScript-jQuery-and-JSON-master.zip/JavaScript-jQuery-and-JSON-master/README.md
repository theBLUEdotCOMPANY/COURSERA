# JavaScript-jQuery-and-JSON

learning notes.

view the course: https://www.coursera.org/learn/javascript-jquery-json